#!/bin/bash

localIP=`ifconfig | grep inet | grep -v 127.0.0.1 | grep -v inet6 | awk '{print $2}'|tr -d "addr:"`

echo "localIP: $localIP"

confPath="conf"
echo "nginx config file: $confPath"

cpuNum=`cat /proc/cpuinfo| grep "processor"| wc -l`
echo "CPU core num: $cpuNum"

nginxconf="./nginx.conf"

cd $confPath

sed -i "s/{cpuNum}/$cpuNum/g" $nginxconf
sed -i "s/{localIP}/$localIP/g" $nginxconf

echo "done...."
